﻿namespace Xadrez.tabuleiro
{
    enum Cor
    {
        Branca,
        Preta
    }
}